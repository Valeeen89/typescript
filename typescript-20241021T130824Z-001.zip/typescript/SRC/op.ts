import { estudiante } from "./estudiante"

export const insertarestudiante = function (estudiante: estudiante, arregloestudiante: estudiante[]) {
    // Instrucción para agregar el estudiante al arreglo
    arregloestudiante.push(estudiante);
    console.log(`Se ha agregado el estudiante: ${estudiante.nombre} ${estudiante.apellido}`);
}

export const actulizarestudiante = function( indice:Number, listaEstudiante:estudiante[], nombre:string, apellido:string
){


//acurualizar
}
export const borrarestudiante = function(inidice:number, listaEstudiante:estudiante[]){
    listaEstudiante.splice(1,1);
}
import{ estudiante } from "./estudiante";
import recorrerestudiantes from "./Recorrerestudiantes";
import { insertarestudiante, actulizarestudiante, borrarestudiante } from "./op";
//definir
const estudiante1: estudiante = {


nombre: "cristian",
apellido: "Buitrago",
edad: 34,
tipoid: "cc",
numid: 12345,
}


const estudiante2: estudiante = {


    nombre: "Mary",
    apellido: "Tomshom",
    edad: 24,
    tipoid: "cc",
    numid: 16345,
    }


const estudiante3: estudiante = {


    nombre: "Santiago",
    apellido: "Guartos",
    tipoid: "cc",
    numid: 23456,
    }

const estudiante4 = {
    nombre: "Ana",
    apellido: "Ramirez",
    tipoid: "cc",
    edad: 18,
    numid: 23452,
};

const estudiante5 = {
    nombre: "Luis",
    apellido: "Fernandez",
    tipoid: "cc",
    edad: 20,
    numid: 23453,
};

const estudiante6 = {
    nombre: "María",
    apellido: "Gonzalez",
    tipoid: "ti",
    numid: 23454,
};

const estudiante7 = {
    nombre: "Juan",
    apellido: "Pérez",
    tipoid: "cc",
    edad: 22,
    numid: 23455,
};

const estudiante8 = {
    nombre: "Sofia",
    apellido: "Lopez",
    tipoid: "cc",
    numid: 23456,
};

const estudiante9 = {
    nombre: "Carlos",
    apellido: "Martinez",
    tipoid: "cc",
    edad: 19,
    numid: 23457,
};

const estudiante10 = {
    nombre: "Laura",
    apellido: "Diaz",
    tipoid: "ti",
    numid: 23458,
};


console.log(estudiante1)
console.log(estudiante2)
console.log(estudiante3)
console.log(estudiante4)
console.log(estudiante5)
console.log(estudiante6)
console.log(estudiante7)
console.log(estudiante8)
console.log(estudiante9)
console.log(estudiante10)


//crear arreglo

const listaEstudiante : estudiante[] =[estudiante1, estudiante2, estudiante3, estudiante4]
console.log (listaEstudiante)

//recorrer arreflo
recorrerestudiantes(listaEstudiante);
// Insertar un nuevo estudiante
const estudiante11: estudiante = {
    nombre: "Maria",
    apellido: "Cortes",
    tipoid: "ti",
    numid: 23458,
};
insertarestudiante(estudiante11, listaEstudiante);
console.log("Lista después de insertar estudiante11:");
console.log(listaEstudiante);

// Actualizar un estudiante en la posición 1
actulizarestudiante(1, listaEstudiante, "Martin", "Portera");
console.log("Lista después de actualizar al estudiante en la posición 1:");
console.log(listaEstudiante);

// Borrar el estudiante en la posición 1
borrarestudiante(1, listaEstudiante);
console.log("Lista después de eliminar al estudiante en la posición 1:");
console.log(listaEstudiante);

//op con arreglo

insertarestudiante(estudiante1, listaEstudiante)



actulizarestudiante(1, listaEstudiante,
    "martin",
"portera")
console.log(listaEstudiante)

borrarestudiante(1, listaEstudiante)
console.log(listaEstudiante)
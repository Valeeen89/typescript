import { estudiante } from "./estudiante";


const arregloestudiante =(arregloestudiante: estudiante[])=>{
    arregloestudiante.forEach(function(elemento)  {
        console.log(elemento);
        console.log("-----------------------")
    });
}

export default arregloestudiante;
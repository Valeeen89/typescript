export type estudiante = {
 nombre: string;
 apellido: string;
 edad?: number | string;
 tipoid: string;
 numid: number;
}